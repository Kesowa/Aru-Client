import * as wasm from "./vtracer_webapp_bg.wasm?url";
import { __wbg_set_wasm } from "./vtracer_webapp_bg.js";
__wbg_set_wasm(wasm);
export * from "./vtracer_webapp_bg.js";

wasm.__wbindgen_start();
